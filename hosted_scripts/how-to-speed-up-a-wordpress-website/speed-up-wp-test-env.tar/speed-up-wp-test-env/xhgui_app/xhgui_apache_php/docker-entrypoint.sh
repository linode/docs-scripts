#!/bin/bash
set -e

# first arg is `-f` or `--some-option`
if [ "${1#-}" != "$1" ]; then
	set -- apache2-foreground "$@"
fi

echo "$(pwd)"

echo "Checking if xhgui already exists"
if [ ! -d xhgui ]; then
	echo "Copying xhgui"
        cp -r /usr/src/xhgui-master ./xhgui
	chown www-data:www-data -R ./xhgui
fi

exec "$@"
