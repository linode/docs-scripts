<?php
   /*
   Plugin Name: Slow Query Test
   */

   function insert_slow_query() {
      global $wpdb;
      $wpdb->query($wpdb->prepare ( "SELECT SLEEP(%d)", array(5) ));
   }

   add_action("wp_head", "insert_slow_query");
?>
