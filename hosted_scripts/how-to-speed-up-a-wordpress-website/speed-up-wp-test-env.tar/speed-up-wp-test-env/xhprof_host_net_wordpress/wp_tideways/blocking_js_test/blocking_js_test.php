<?php
   /*
   Plugin Name: Blocking JS Test
   */

   function insert_blocking_js() {
	?>
	<script>
		function sleep( timeInMilliseconds ){
			var now = new Date().getTime();
			while(new Date().getTime() < now + timeInMilliseconds){ }
		}

		sleep(5000);
	</script>
	<?php
   }

   add_action("wp_head", "insert_blocking_js");
?>
