<?php
	/*
	Plugin Name: Pi Widget
	*/

	class Pi_Widget extends WP_Widget {

		public function __construct() {
			parent::__construct(
				'pi_widget',
				__( 'Pi Widget', 'text_domain' ),
				array(
					'customize_selective_refresh' => true,
				)
			);
		}

		public function form( $instance ) {	
			/* ... */
		}

		public function update( $new_instance, $old_instance ) {
			/* ... */
		}

		public function calculatePi() {
			$pi = 4;
			$iterations = 100000000;

			for($i = 1; $i < $iterations; $i++)
			{
				$sign = $i % 2 ? -1 : 1;
				$increment = $sign * 4 / (2*$i + 1);
				$pi += $increment;
			}

			return $pi;
		}

		// Display the widget
		public function widget( $args, $instance ) {
			extract( $args );

			echo $before_widget;

			echo '<div class="widget-text wp_widget_plugin_box" style="background: #eeeeee">';
			echo '<p style="background: green; padding: 10px; color: white; border-bottom: 2px solid white; margin-bottom: 0px;">';
			echo 'Did you know? Pi can be approximated with a Taylor Series: <a style="color: white;" href="https:/www.math.hmc.edu/funfacts/ffiles/30001.1-3.shtml">Taylor-Made Pi</a>';
			echo '</p>';
			echo '<p style="padding: 10px;">This value of Pi was calculated with 100 billion iterations of the algorithm: <br><strong>';
			echo $this->calculatePi();
			echo '</strong></p>';
			echo '</div>';

			echo $after_widget;
		}

	}

	// Register the widget
	function my_register_custom_widget() {
		register_widget( 'Pi_Widget' );
	}
	add_action( 'widgets_init', 'my_register_custom_widget' );

?>
