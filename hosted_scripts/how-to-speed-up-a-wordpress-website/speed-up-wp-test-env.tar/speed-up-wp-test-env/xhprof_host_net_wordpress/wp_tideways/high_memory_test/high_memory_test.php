<?php
   /*
   Plugin Name: High Memory Test
   */

   function high_memory_test() {
	for ($i=0; $i < 30; $i++) {
		$data = openssl_random_pseudo_bytes(1000000);
	}
   }

   add_action("wp_head", "high_memory_test");
?>
